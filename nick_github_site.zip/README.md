# Nick Befort Coaching – Static Site

This is a one-file static website for GitHub Pages or Netlify.

## Deploy on GitHub Pages
1. Create a new public repository (e.g., `nickbefort-coaching`).
2. Upload `index.html` to the root of the repo.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, select **Branch: main**, Folder: **/**, then **Save**.
5. Your site will be live at `https://<your-username>.github.io/nickbefort-coaching`.

## Deploy on Netlify
- Use Netlify Drop and drag `index.html`, or zip it first and drop the zip.
